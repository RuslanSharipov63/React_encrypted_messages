
import React, {useState} from 'react';
import env from '../env.json';

function Create() {

  /* делаем стейты для вывода ссылки */
  const [url, setUrl] = useState('');
  const [lineClass, setLineClass] = useState('hide');
  const [formClass, setFormClass] = useState('');

  let sendData = (obj) => {/* эту функция отправляет данные на сервер */
   
    setFormClass('hide');
    setLineClass(''); 
    
    fetch(env.urlBackend, {
      method : 'POST', 
      headers : {
        'Content-type': 'application/x-www-form-urlencoded',
      },
      body : JSON.stringify(obj)
    })
    .then(response => response.json())/* трансформируем ответ от сервера в json */
    .then(response => {
      console.log(response)
      if(response.result) {/* у нас в json удет поле result с true или false */
        setUrl(env.url+'/'+response.url); /* ответ сервера, который придет от бэкенда. по договоренности хэш будет присылаться в поле url - по договоренности с бэкенд-разработчиком */
        /* НО у нас два раза дублируется http://localhost:3500, когда будем переносить на реальный сервер его еще надо будет найти и не потерять. поэтому подобные параметры удобно переносить в отдельный файл. поэтому в src создаем файл env.json - возьмите это за правило, это хорошая привычка - там у нас будут параметры проекта*/
      }
    })
  } 

  let loadDataFromForm = (event) => {
    event.preventDefault();
    /* здесь мы можем сами сделать проверку на пустую форму */
    let note = event.target.elements.note.value; /* получаем все элементы формы */
   
    note = note.trim();
    if(note === '') {
      alert('Заполните поля'); /* здесь потом можно будет сделать всплывающее окно */
      return false;
    }
    sendData({"note" : note}); /* то есть у нас одна функция проверяет форму, другая отправляет данные на сервер. в качестве параметра передали текст из формы  */
  }

  return (
    <div>
      <form onSubmit={loadDataFromForm} className={formClass}> {/* action пустой, его вообще удалили, так как мы будем отправлять форму на данный файл. никуда мы уходить не будем */}

        <label htmlFor="">Введите заметку</label> {/* в хтмл файлах атрибут for, здесь htmlFor */}
        <textarea name="note" id="note" defaultValue="Test"></textarea>{/* по id textarea будет связан с label */}
        <button type="submit">Создать</button>
      </form>
   <div className={lineClass}> {/* это будейт стейт */}
        <div>{url}</div>
        <div><button onClick={function() {
          window.location.reload()
        }}>Создать новую заметку</button></div>
        </div>
    </div>
  );
}

export default Create;
